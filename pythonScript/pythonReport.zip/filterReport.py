# expecting filenames HitCounts.txt and SNPreport.txt
# expecting files: fixedHitCounts.txt and fixedSNPreport.txt

import csv
#Psy1.D1_48

def trimEndNumber(name):
    i = len(name) - 1
    while i >= 0:
        if name[i] == "_":
            name = name[0:i]
            return name
        i -= 1
    return name

errorDictionary = {}
averageDictionary = {}
keysArray = []
firstColumn = []
fileObject = open('fixedHitCounts.txt', 'w')
fileObject.truncate(0)
fileObject.write("Tag	1A1D_A01_S6_R1_001	1A1D_A04_S7_R1_001	1B1A_B01_S8_R1_001	1B1A_B04_S9_R1_001	1D1B_C01_S10_R1_001	1D1B_C04_S11_R1_001	2154_S1_R1_001	2375_S2_R1_001	2552_S3_R1_001	2B2D_E01_S12_R1_001	2B2D_E04_S13_R1_001	2D2A_D01_S14_R1_001	2D2A_D04_S15_R1_001	2D2B_F01_S16_R1_001	2D2B_F04_S17_R1_001	3A3D_G01_S18_R1_001	3A3D_G04_S19_R1_001	3B3A_H01_S20_R1_001	3B3A_H04_S21_R1_001	3D3B_A02_S22_R1_001	3D3B_A05_S23_R1_001	4A4B_C02_S24_R1_001	4A4B_C05_S25_R1_001	4A4D_B02_S26_R1_001	4A4D_B05_S27_R1_001	4D4B_D02_S28_R1_001	4D4B_D05_S29_R1_001	5A5D_E02_S30_R1_001	5A5D_E05_S31_R1_001	5B5A_F02_S32_R1_001	5B5A_F05_S33_R1_001	5D5B_G02_S34_R1_001	5D5B_G05_S35_R1_001	6A6B_A03_S36_R1_001	6A6B_A06_S37_R1_001	6A6D_H02_S38_R1_001	6A6D_H05_S39_R1_001	6D6B_B03_S40_R1_001	6D6B_B06_S41_R1_001	7805_S4_R1_001	7833_S5_R1_001	7A7D_C03_S42_R1_001	7A7D_C06_S43_R1_001	7B7A_D03_S44_R1_001	7B7A_D06_S45_R1_001	7D7B_E03_S46_R1_001	7D7B_E06_S47_R1_001	Abilene_S48_R1_001	Allegiance_S49_R1_001	Antelope_S50_R1_001	Arrowsmith_S51_R1_001	Augusta_S52_R1_001	Bess_S53_R1_001	Bighorn_S54_R1_001	Clark_S55_R1_001	Colby_94_S56_R1_001	Compton_S57_R1_001	Discovery_S58_R1_001	Dowel_S59_R1_001	Eider_S60_R1_001	Era_S61_R1_001	Fulcaster_S62_R1_001	Glenman_S63_R1_001	Goodstreak_S64_R1_001	Grant_S65_R1_001	Hallam_S66_R1_001	Harry_S67_R1_001	Hart_S68_R1_001	Haven_S69_R1_001	Hi_Line_S70_R1_001	Hickory_S71_R1_001	Hillsdale_S72_R1_001	Horizon_101_S73_R1_001	Leapland_S74_R1_001	Leif_S75_R1_001	Lewis_S76_R1_001	Longhorn_S77_R1_001	Minnpro_S78_R1_001	Nekota_S79_R1_001	Norak_S80_R1_001	Norwin_S81_R1_001	Pacer_S82_R1_001	Pecos_S83_R1_001	Pontiac_S84_R1_001	Prospur_S85_R1_001	Protor_S86_R1_001	Rampart_S87_R1_001	Rio_Blanco_S88_R1_001	Steele_S89_R1_001	Stoddard_S90_R1_001	Tecumseh_S91_R1_001	Tiber_S92_R1_001	Todd_S93_R1_001	Vance_S94_R1_001	Vanguard_S95_R1_001	Weaco_S96_R1_001" + "\n")

fileObject.close()
outputArray = []
with open('HitCounts.txt') as csvfile:
    csvreader = csv.reader(csvfile, delimiter='\t')
    lineCount = 0
    lineSum = 0
    for row in csvreader:
        #FIRST RUN THROUGH START
        
        i = 1
        while i < len(row):

            if row[i] != '':
                outputArray.append(row[i])
                if lineCount > 1:
                    lineSum += int(row[i])
            i += 1
        
        outputArray.insert(0, row[0])
        if lineCount == 0:
            keysArray = outputArray
        else:
            if row[0] not in errorDictionary:
                errorDictionary[row[0]] = {}
            averageDictionary[row[0]] = lineSum
            firstColumn.append(row[0])

        lineCount += 1
        
        print(lineSum)
        lineSum = 0
        #FIRST RUN THROUGH END

        #SECOND RUN THROUGH START
        outputArray = []
        i = 1
        if lineCount > 1:
            while i < len(row):

                if row[i] != '':
                    if lineCount > 1 and int(row[i]) < (averageDictionary[row[0]]/ (len(row) - 1 ) * .01): # len(row)-1 should be NumberOfSamples (DOUBLE CHECK THIS)
                        outputArray.append(0)
                        errorDictionary[row[0]][keysArray[i]] = 0
                    else:
                        outputArray.append(int(row[i]))

                i += 1

            fileObject = open('fixedHitCounts.txt', 'a')
            
            fileObject.write(row[0])
            for i in range(len(outputArray)):
                fileObject.write("\t" + str(outputArray[i]))
            
            fileObject.write("\n")
            fileObject.close()

fileObject = open('fixedSNPreport.txt', 'w')
fileObject.truncate(0)
fileObject.write("TagPos	1A1D_A01_S6_R1_001	1A1D_A04_S7_R1_001	1B1A_B01_S8_R1_001	1B1A_B04_S9_R1_001	1D1B_C01_S10_R1_001	1D1B_C04_S11_R1_001	2154_S1_R1_001	2375_S2_R1_001	2552_S3_R1_001	2B2D_E01_S12_R1_001	2B2D_E04_S13_R1_001	2D2A_D01_S14_R1_001	2D2A_D04_S15_R1_001	2D2B_F01_S16_R1_001	2D2B_F04_S17_R1_001	3A3D_G01_S18_R1_001	3A3D_G04_S19_R1_001	3B3A_H01_S20_R1_001	3B3A_H04_S21_R1_001	3D3B_A02_S22_R1_001	3D3B_A05_S23_R1_001	4A4B_C02_S24_R1_001	4A4B_C05_S25_R1_001	4A4D_B02_S26_R1_001	4A4D_B05_S27_R1_001	4D4B_D02_S28_R1_001	4D4B_D05_S29_R1_001	5A5D_E02_S30_R1_001	5A5D_E05_S31_R1_001	5B5A_F02_S32_R1_001	5B5A_F05_S33_R1_001	5D5B_G02_S34_R1_001	5D5B_G05_S35_R1_001	6A6B_A03_S36_R1_001	6A6B_A06_S37_R1_001	6A6D_H02_S38_R1_001	6A6D_H05_S39_R1_001	6D6B_B03_S40_R1_001	6D6B_B06_S41_R1_001	7805_S4_R1_001	7833_S5_R1_001	7A7D_C03_S42_R1_001	7A7D_C06_S43_R1_001	7B7A_D03_S44_R1_001	7B7A_D06_S45_R1_001	7D7B_E03_S46_R1_001	7D7B_E06_S47_R1_001	Abilene_S48_R1_001	Allegiance_S49_R1_001	Antelope_S50_R1_001	Arrowsmith_S51_R1_001	Augusta_S52_R1_001	Bess_S53_R1_001	Bighorn_S54_R1_001	Clark_S55_R1_001	Colby_94_S56_R1_001	Compton_S57_R1_001	Discovery_S58_R1_001	Dowel_S59_R1_001	Eider_S60_R1_001	Era_S61_R1_001	Fulcaster_S62_R1_001	Glenman_S63_R1_001	Goodstreak_S64_R1_001	Grant_S65_R1_001	Hallam_S66_R1_001	Harry_S67_R1_001	Hart_S68_R1_001	Haven_S69_R1_001	Hi_Line_S70_R1_001	Hickory_S71_R1_001	Hillsdale_S72_R1_001	Horizon_101_S73_R1_001	Leapland_S74_R1_001	Leif_S75_R1_001	Lewis_S76_R1_001	Longhorn_S77_R1_001	Minnpro_S78_R1_001	Nekota_S79_R1_001	Norak_S80_R1_001	Norwin_S81_R1_001	Pacer_S82_R1_001	Pecos_S83_R1_001	Pontiac_S84_R1_001	Prospur_S85_R1_001	Protor_S86_R1_001	Rampart_S87_R1_001	Rio_Blanco_S88_R1_001	Steele_S89_R1_001	Stoddard_S90_R1_001	Tecumseh_S91_R1_001	Tiber_S92_R1_001	Todd_S93_R1_001	Vance_S94_R1_001	Vanguard_S95_R1_001	Weaco_S96_R1_001" + "\n")

fileObject.close()
outputArray = []
with open('SNPreport.txt') as csvfile:
    csvreader = csv.reader(csvfile, delimiter='\t')
    lineCount = 0
    lineSum = 0
    #print(keysArray)
    for row in csvreader:
        #print(row)
        if lineCount > 0:
            i = 1
            while i < len(row):

                if row[i] != '':
                    if lineCount > 0:
                        #print(row[0])
                        #print(errorDictionary)
                        savedStr = trimEndNumber(row[0])
                        
                        if savedStr in errorDictionary:
                            #print(errorDictionary[row[0]])
                            if keysArray[i] in errorDictionary[savedStr]: #errorDictionary[row[0]]
                                outputArray.append("-")
                            else:
                                outputArray.append(row[i])
                        else:
                            outputArray.append(row[i])
                i += 1
        
        fileObject = open('fixedSNPreport.txt', 'a')
        if lineCount > 0:
            fileObject.write(row[0])

            for i in range(len(outputArray)):
                fileObject.write("\t" + outputArray[i])
            
            fileObject.write("\n")
        fileObject.close()

        lineCount += 1
        outputArray = []
        
    

